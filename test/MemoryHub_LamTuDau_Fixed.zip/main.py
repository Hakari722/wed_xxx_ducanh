import os, sqlite3, secrets
from pathlib import Path
from datetime import datetime
from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

ROOT=Path(__file__).resolve().parent
UPLOADS=ROOT/"uploads"; UPLOADS.mkdir(exist_ok=True)
DB=ROOT/"memoryhub.db"
ADMIN_PASSWORD=os.getenv("ADMIN_PASSWORD","")
app=FastAPI(title="MemoryHub")
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SESSION_SECRET","local-only-change-this"), same_site="lax", https_only=os.getenv("COOKIE_HTTPS_ONLY","false").lower()=="true")
app.mount("/static",StaticFiles(directory=ROOT/"static"),name="static")
app.mount("/uploads",StaticFiles(directory=UPLOADS),name="uploads")
templates=Jinja2Templates(directory=ROOT/"templates")

def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
with db() as c:
    c.execute("""CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT NOT NULL,description TEXT DEFAULT '',url TEXT NOT NULL,thumbnail TEXT DEFAULT '',created_at TEXT NOT NULL)""")

def admin(req): return req.session.get("admin") is True
def rows(q=""):
    with db() as c:
        if q.strip():
            term="%"+q.strip()+"%"
            data=c.execute("SELECT * FROM videos WHERE title LIKE ? OR description LIKE ? ORDER BY id DESC",(term,term)).fetchall()
        else: data=c.execute("SELECT * FROM videos ORDER BY id DESC").fetchall()
    return [dict(id=r["id"],title=r["title"],description=r["description"],url=r["url"],thumbnail=r["thumbnail"],uploaded_at=r["created_at"]) for r in data]

@app.get("/",response_class=HTMLResponse)
def home(request:Request): return templates.TemplateResponse("index.html",{"request":request})
@app.get("/api/videos")
def api_videos(q:str=""): return rows(q)
@app.get("/admin/login",response_class=HTMLResponse)
def login_page(request:Request): return RedirectResponse("/admin",303) if admin(request) else templates.TemplateResponse("login.html",{"request":request,"error":None})
@app.post("/admin/login",response_class=HTMLResponse)
def login(request:Request,password:str=Form(...)):
    if not ADMIN_PASSWORD:
        return templates.TemplateResponse("login.html",{"request":request,"error":"Chưa đặt ADMIN_PASSWORD trong Terminal."},status_code=500)
    if not secrets.compare_digest(password,ADMIN_PASSWORD):
        return templates.TemplateResponse("login.html",{"request":request,"error":"Mật khẩu không đúng."},status_code=401)
    request.session["admin"]=True
    return RedirectResponse("/admin",303)
@app.post("/admin/logout")
def logout(request:Request):
    request.session.clear(); return RedirectResponse("/",303)
@app.get("/admin",response_class=HTMLResponse)
def admin_page(request:Request):
    if not admin(request): return RedirectResponse("/admin/login",303)
    return templates.TemplateResponse("admin.html",{"request":request,"videos":rows()})
@app.post("/admin/upload")
async def upload(request:Request,title:str=Form(...),description:str=Form(""),video:UploadFile=File(...),thumbnail:UploadFile|None=File(None)):
    if not admin(request): raise HTTPException(403,"Admin only")
    title=title.strip()
    if not title: raise HTTPException(400,"Cần nhập tên video")
    ext=Path(video.filename or "").suffix.lower()
    if ext not in {".mp4",".webm",".mov",".m4v",".ogv"}: raise HTTPException(400,"Chỉ nhận MP4, WebM, MOV, M4V hoặc OGV")
    max_bytes=int(os.getenv("MAX_UPLOAD_MB","500"))*1024*1024
    data=await video.read(max_bytes+1)
    if len(data)>max_bytes: raise HTTPException(413,"Video quá dung lượng cho phép")
    if not data: raise HTTPException(400,"File rỗng")
    name=secrets.token_hex(16)+ext; (UPLOADS/name).write_bytes(data); url="/uploads/"+name; thumb_url=""
    if thumbnail and thumbnail.filename:
        te=Path(thumbnail.filename).suffix.lower()
        if te not in {".jpg",".jpeg",".png",".webp"}: raise HTTPException(400,"Ảnh bìa cần là JPG, PNG hoặc WebP")
        td=await thumbnail.read(8*1024*1024+1)
        if len(td)>8*1024*1024: raise HTTPException(413,"Ảnh bìa tối đa 8 MB")
        tn=secrets.token_hex(16)+te; (UPLOADS/tn).write_bytes(td); thumb_url="/uploads/"+tn
    with db() as c:
        c.execute("INSERT INTO videos(title,description,url,thumbnail,created_at) VALUES(?,?,?,?,?)",(title,description.strip(),url,thumb_url,datetime.now().strftime("%Y-%m-%d %H:%M")))
    return RedirectResponse("/admin?uploaded=1",303)
@app.post("/admin/delete/{vid}")
def delete(request:Request,vid:int):
    if not admin(request): raise HTTPException(403,"Admin only")
    with db() as c:
        r=c.execute("SELECT url,thumbnail FROM videos WHERE id=?",(vid,)).fetchone()
        if not r: raise HTTPException(404,"Không tìm thấy video")
        for value in (r["url"],r["thumbnail"]):
            if value.startswith("/uploads/"):
                p=UPLOADS/Path(value).name
                if p.exists(): p.unlink()
        c.execute("DELETE FROM videos WHERE id=?",(vid,))
    return RedirectResponse("/admin?deleted=1",303)
@app.get("/health")
def health(): return {"status":"ok"}
